package com.example.urlgallery;

import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveInputStream;
import org.apache.commons.compress.archivers.ArchiveStreamFactory;
import org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry;
import org.apache.commons.compress.archivers.sevenz.SevenZFile;
import org.apache.commons.compress.archivers.zip.ZipArchiveInputStream;
import org.apache.commons.compress.compressors.CompressorStreamFactory;
import org.apache.commons.compress.utils.SeekableInMemoryByteChannel;

import com.github.junrar.Archive;
import com.github.junrar.rarfile.FileHeader;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Streams an archive (zip, rar, 7z, tar, tar.gz/bz2/xz) from a URL and keeps its images
 * in encrypted temporary storage (see Store). Class name kept for simplicity.
 */
public class ZipLoader {

    public interface Progress {
        void update(String text);
    }

    public static class Result {
        public final ArrayList<String> ids = new ArrayList<>();
        public String warning;
    }

    private static final int MAX_ENTRY = 150 * 1024 * 1024;
    private static final long MAX_7Z_BYTES = 450L * 1024 * 1024;

    /** Collects images as they come out of an archive. */
    private static class State {
        final Progress progress;
        final AtomicBoolean cancel;
        final ArrayList<String> names = new ArrayList<>();
        final ArrayList<Integer> idxs = new ArrayList<>();
        final LinkedHashSet<String> exts = new LinkedHashSet<>();
        int fileCount = 0;
        String warning;

        State(Progress p, AtomicBoolean c) {
            progress = p;
            cancel = c;
        }

        void noteFile(String name) {
            fileCount++;
            int dot = name.lastIndexOf('.');
            String ext = (dot >= 0 && dot > name.lastIndexOf('/'))
                    ? name.substring(dot).toLowerCase(Locale.ROOT) : "(none)";
            if (exts.size() < 6) exts.add(ext);
        }

        /** Returns false if loading should stop. */
        boolean add(String name, byte[] data) {
            int idx;
            try {
                idx = Store.add(data);
            } catch (IOException | OutOfMemoryError err) {
                warning = "Stopped after " + names.size() + " images: "
                        + (err instanceof IOException ? err.getMessage() : "out of memory") + ".";
                return false;
            }
            names.add(name);
            idxs.add(idx);
            progress.update("Loading… " + names.size() + " images, "
                    + (Store.totalBytes() / (1024 * 1024)) + " MB");
            return true;
        }
    }

    public static Result load(String url, Progress progress, AtomicBoolean cancel) throws IOException {
        final Result res = new Result();
        HttpURLConnection c = ImageLoader.open(url);
        if (c == null) throw new IOException("the server refused the download");

        State st = new State(progress, cancel);
        try {
            BufferedInputStream bin = new BufferedInputStream(c.getInputStream(), 65536);
            bin.mark(65536);
            byte[] head = new byte[8];
            int got = 0;
            int r;
            while (got < head.length && (r = bin.read(head, got, head.length - got)) > 0) got += r;
            bin.reset();

            String fmt = sniff(head, got);
            switch (fmt) {
                case "zip":
                    readStream(new ZipArchiveInputStream(bin, "UTF8", true, true), st);
                    break;
                case "rar4":
                    readRar(bin, st);
                    break;
                case "rar5":
                    throw new IOException("this is a RAR5 archive, which the app can't open. "
                            + "Re-pack it as zip, 7z or an older RAR");
                case "7z":
                    read7z(bin, c.getContentLengthLong(), st);
                    break;
                case "gz":
                case "bz2":
                case "xz":
                    readCompressed(bin, st);
                    break;
                default:
                    readAuto(bin, st, c.getContentType(), head, got);
                    break;
            }
        } catch (IOException | RuntimeException ex) {
            if (st.names.isEmpty()) {
                throw new IOException(ex.getMessage() == null ? ex.toString() : ex.getMessage());
            }
            st.warning = "Download interrupted after " + st.names.size() + " images.";
        } finally {
            c.disconnect();
        }

        res.warning = st.warning;
        if (st.names.isEmpty() && res.warning == null) {
            res.warning = st.fileCount == 0
                    ? "the archive opened but contained no files."
                    : "the archive had " + st.fileCount + " files but none were images (types: " + st.exts + ").";
        }

        ArrayList<Integer> order = new ArrayList<>();
        for (int i = 0; i < st.names.size(); i++) order.add(i);
        final ArrayList<String> fn = st.names;
        Collections.sort(order, new Comparator<Integer>() {
            @Override
            public int compare(Integer a, Integer b) {
                return natural(fn.get(a), fn.get(b));
            }
        });
        for (int i : order) res.ids.add("mem:" + st.idxs.get(i));
        return res;
    }

    // ---------- format readers ----------

    @SuppressWarnings("rawtypes")
    private static void readStream(ArchiveInputStream ais, State st) throws IOException {
        try {
            ArchiveEntry e;
            while ((e = ais.getNextEntry()) != null) {
                if (st.cancel.get()) break;
                if (e.isDirectory()) continue;
                String name = e.getName();
                st.noteFile(name);
                if (!isImage(name)) continue;
                if (!ais.canReadEntryData(e)) continue;
                byte[] data = readAll(ais);
                if (data == null) continue;
                if (!st.add(name, data)) break;
            }
        } finally {
            try {
                ais.close();
            } catch (IOException ignore) {
            }
        }
    }

    private static void readRar(InputStream in, State st) throws IOException {
        Archive archive = null;
        try {
            archive = new Archive(in);
            FileHeader fh;
            while ((fh = archive.nextFileHeader()) != null) {
                if (st.cancel.get()) break;
                if (fh.isDirectory()) continue;
                String name = rarName(fh);
                st.noteFile(name);
                if (!isImage(name)) continue;
                InputStream is = archive.getInputStream(fh);
                byte[] data;
                try {
                    data = readAll(is);
                } finally {
                    is.close();
                }
                if (data == null) continue;
                if (!st.add(name, data)) break;
            }
        } catch (IOException e) {
            throw e;
        } catch (Exception e) {
            throw new IOException("couldn't read the RAR: " + (e.getMessage() == null ? e.toString() : e.getMessage()));
        } finally {
            if (archive != null) {
                try {
                    archive.close();
                } catch (Exception ignore) {
                }
            }
        }
    }

    /** Looks up the entry name without depending on which method name this junrar version uses. */
    private static String rarName(FileHeader fh) {
        String[] methods = {"getFileName", "getFileNameString"};
        for (String m : methods) {
            try {
                Object o = fh.getClass().getMethod(m).invoke(fh);
                if (o != null) return o.toString().replace('\\', '/');
            } catch (Exception ignore) {
            }
        }
        return "unknown";
    }

    private static void read7z(InputStream in, long contentLength, State st) throws IOException {
        if (contentLength > MAX_7Z_BYTES) {
            throw new IOException("this 7z is too large for the app (7z files must fit in memory; limit "
                    + (MAX_7Z_BYTES / (1024 * 1024)) + " MB). A zip or RAR would work");
        }
        byte[] bytes;
        try {
            if (contentLength > 0) {
                bytes = new byte[(int) contentLength];
                int off = 0;
                while (off < bytes.length) {
                    int n = in.read(bytes, off, bytes.length - off);
                    if (n < 0) break;
                    off += n;
                    if (st.cancel.get()) return;
                }
                if (off < bytes.length) {
                    bytes = java.util.Arrays.copyOf(bytes, off);
                }
            } else {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[65536];
                int n;
                long total = 0;
                while ((n = in.read(buf)) > 0) {
                    out.write(buf, 0, n);
                    total += n;
                    if (total > MAX_7Z_BYTES) {
                        throw new IOException("this 7z is too large for the app (limit "
                                + (MAX_7Z_BYTES / (1024 * 1024)) + " MB)");
                    }
                    if (st.cancel.get()) return;
                }
                bytes = out.toByteArray();
            }
        } catch (OutOfMemoryError oom) {
            throw new IOException("not enough memory for this 7z");
        }

        SevenZFile sz = null;
        try {
            sz = new SevenZFile(new SeekableInMemoryByteChannel(bytes));
            SevenZArchiveEntry e;
            while ((e = sz.getNextEntry()) != null) {
                if (st.cancel.get()) break;
                if (e.isDirectory()) continue;
                String name = e.getName();
                st.noteFile(name);
                if (!isImage(name)) continue;
                long size = e.getSize();
                if (size < 0 || size > MAX_ENTRY) continue;
                byte[] data = new byte[(int) size];
                int off = 0;
                while (off < data.length) {
                    int n = sz.read(data, off, data.length - off);
                    if (n < 0) break;
                    off += n;
                }
                if (off < data.length) continue;
                if (!st.add(name, data)) break;
            }
        } catch (IOException e) {
            throw e;
        } catch (Exception e) {
            throw new IOException("couldn't read the 7z: " + (e.getMessage() == null ? e.toString() : e.getMessage()));
        } finally {
            if (sz != null) {
                try {
                    sz.close();
                } catch (IOException ignore) {
                }
            }
        }
    }

    @SuppressWarnings("rawtypes")
    private static void readCompressed(BufferedInputStream bin, State st) throws IOException {
        try {
            InputStream dec = new CompressorStreamFactory().createCompressorInputStream(bin);
            BufferedInputStream b2 = new BufferedInputStream(dec, 65536);
            ArchiveInputStream ais = new ArchiveStreamFactory().createArchiveInputStream(b2);
            readStream(ais, st);
        } catch (IOException e) {
            throw e;
        } catch (Exception e) {
            throw new IOException("this compressed file isn't an archive of images");
        }
    }

    @SuppressWarnings("rawtypes")
    private static void readAuto(BufferedInputStream bin, State st, String contentType,
                                 byte[] head, int got) throws IOException {
        ArchiveInputStream ais;
        try {
            ais = new ArchiveStreamFactory().createArchiveInputStream(bin);
        } catch (Exception e) {
            StringBuilder hex = new StringBuilder();
            for (int i = 0; i < Math.min(got, 4); i++) {
                if (i > 0) hex.append(' ');
                hex.append(String.format(Locale.ROOT, "%02X", head[i] & 0xff));
            }
            throw new IOException("unrecognised archive format (server sent "
                    + (contentType == null ? "an unknown type" : contentType)
                    + ", file starts with " + hex + ")");
        }
        readStream(ais, st);
    }

    // ---------- helpers ----------

    static String sniff(byte[] h, int n) {
        if (n >= 4 && h[0] == 'P' && h[1] == 'K') return "zip";
        if (n >= 7 && h[0] == 'R' && h[1] == 'a' && h[2] == 'r' && h[3] == '!'
                && h[4] == 0x1a && h[5] == 0x07) {
            return h[6] == 0 ? "rar4" : "rar5";
        }
        if (n >= 6 && h[0] == '7' && h[1] == 'z' && (h[2] & 0xff) == 0xBC && (h[3] & 0xff) == 0xAF) return "7z";
        if (n >= 2 && (h[0] & 0xff) == 0x1f && (h[1] & 0xff) == 0x8b) return "gz";
        if (n >= 3 && h[0] == 'B' && h[1] == 'Z' && h[2] == 'h') return "bz2";
        if (n >= 6 && (h[0] & 0xff) == 0xfd && h[1] == '7' && h[2] == 'z' && h[3] == 'X' && h[4] == 'Z') return "xz";
        return "other";
    }

    private static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream(256 * 1024);
        byte[] buf = new byte[16384];
        int n;
        long total = 0;
        boolean tooBig = false;
        while ((n = in.read(buf)) > 0) {
            total += n;
            if (total > MAX_ENTRY) {
                tooBig = true;
                continue; // keep draining so the stream stays in sync
            }
            if (!tooBig) out.write(buf, 0, n);
        }
        return tooBig ? null : out.toByteArray();
    }

    static boolean isImage(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        if (n.startsWith("__macosx/")) return false;
        int slash = n.lastIndexOf('/');
        String base = slash >= 0 ? n.substring(slash + 1) : n;
        if (base.startsWith("._")) return false;
        return base.endsWith(".jpg") || base.endsWith(".jpeg") || base.endsWith(".png")
                || base.endsWith(".webp") || base.endsWith(".gif") || base.endsWith(".bmp")
                || base.endsWith(".avif") || base.endsWith(".heic");
    }

    static int natural(String a, String b) {
        int i = 0, j = 0;
        while (i < a.length() && j < b.length()) {
            char x = a.charAt(i), y = b.charAt(j);
            if (Character.isDigit(x) && Character.isDigit(y)) {
                int si = i;
                while (i < a.length() && Character.isDigit(a.charAt(i))) i++;
                int sj = j;
                while (j < b.length() && Character.isDigit(b.charAt(j))) j++;
                String na = a.substring(si, i).replaceFirst("^0+(?=.)", "");
                String nb = b.substring(sj, j).replaceFirst("^0+(?=.)", "");
                if (na.length() != nb.length()) return na.length() - nb.length();
                int c = na.compareTo(nb);
                if (c != 0) return c;
            } else {
                char lx = Character.toLowerCase(x), ly = Character.toLowerCase(y);
                if (lx != ly) return lx - ly;
                i++;
                j++;
            }
        }
        return (a.length() - i) - (b.length() - j);
    }
}
