package com.example.urlgallery;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Streams a zip from a URL and keeps its images in memory (see Store). */
public class ZipLoader {

    public interface Progress {
        void update(String text);
    }

    public static class Result {
        public final ArrayList<String> ids = new ArrayList<>();
        public String warning;
    }

    private static final int MAX_ENTRY = 150 * 1024 * 1024;

    public static Result load(String url, Progress progress, AtomicBoolean cancel) throws IOException {
        final Result res = new Result();
        HttpURLConnection c = ImageLoader.open(url);
        if (c == null) throw new IOException("the server refused the download");

        final ArrayList<String> names = new ArrayList<>();
        final ArrayList<Integer> idxs = new ArrayList<>();
        ZipInputStream zin = null;
        try {
            zin = new ZipInputStream(new BufferedInputStream(c.getInputStream(), 65536));
            ZipEntry e;
            while ((e = zin.getNextEntry()) != null) {
                if (cancel.get()) break;
                String name = e.getName();
                if (e.isDirectory() || !isImage(name)) {
                    zin.closeEntry();
                    continue;
                }
                byte[] data = readEntry(zin);
                zin.closeEntry();
                if (data == null) continue;
                int idx;
                try {
                    idx = Store.add(data);
                } catch (IOException | OutOfMemoryError err) {
                    res.warning = "Stopped after " + names.size() + " images: "
                            + (err instanceof IOException ? err.getMessage() : "out of memory") + ".";
                    break;
                }
                names.add(name);
                idxs.add(idx);
                progress.update("Loading zip… " + names.size() + " images, "
                        + (Store.totalBytes() / (1024 * 1024)) + " MB");
            }
        } catch (IOException | RuntimeException ex) {
            if (names.isEmpty()) {
                throw new IOException(ex.getMessage() == null ? ex.toString() : ex.getMessage());
            }
            res.warning = "Download interrupted after " + names.size() + " images.";
        } finally {
            try {
                if (zin != null) zin.close();
            } catch (IOException ignore) {
            }
            c.disconnect();
        }

        ArrayList<Integer> order = new ArrayList<>();
        for (int i = 0; i < names.size(); i++) order.add(i);
        final ArrayList<String> fn = names;
        Collections.sort(order, new Comparator<Integer>() {
            @Override
            public int compare(Integer a, Integer b) {
                return natural(fn.get(a), fn.get(b));
            }
        });
        for (int i : order) res.ids.add("mem:" + idxs.get(i));
        return res;
    }

    private static byte[] readEntry(ZipInputStream zin) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream(256 * 1024);
        byte[] buf = new byte[16384];
        int n;
        long total = 0;
        boolean tooBig = false;
        while ((n = zin.read(buf)) > 0) {
            total += n;
            if (total > MAX_ENTRY) {
                tooBig = true;
                out = null;
                continue; // keep draining so the stream stays in sync
            }
            if (out != null) out.write(buf, 0, n);
        }
        return tooBig ? null : out.toByteArray();
    }

    static boolean isImage(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        if (n.startsWith("__macosx/")) return false;
        int slash = n.lastIndexOf('/');
        String base = slash >= 0 ? n.substring(slash + 1) : n;
        if (base.startsWith("._")) return false;
        return base.endsWith(".jpg") || base.endsWith(".jpeg") || base.endsWith(".png")
                || base.endsWith(".webp") || base.endsWith(".gif") || base.endsWith(".bmp");
    }

    static int natural(String a, String b) {
        int i = 0, j = 0;
        while (i < a.length() && j < b.length()) {
            char x = a.charAt(i), y = b.charAt(j);
            if (Character.isDigit(x) && Character.isDigit(y)) {
                int si = i;
                while (i < a.length() && Character.isDigit(a.charAt(i))) i++;
                int sj = j;
                while (j < b.length() && Character.isDigit(b.charAt(j))) j++;
                String na = a.substring(si, i).replaceFirst("^0+(?=.)", "");
                String nb = b.substring(sj, j).replaceFirst("^0+(?=.)", "");
                if (na.length() != nb.length()) return na.length() - nb.length();
                int c = na.compareTo(nb);
                if (c != 0) return c;
            } else {
                char lx = Character.toLowerCase(x), ly = Character.toLowerCase(y);
                if (lx != ly) return lx - ly;
                i++;
                j++;
            }
        }
        return (a.length() - i) - (b.length() - j);
    }
}
