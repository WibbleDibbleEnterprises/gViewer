package com.example.urlgallery;

import android.content.Context;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.ViewParent;
import android.widget.ImageView;

/** ImageView with double-tap zoom, pinch zoom and panning. */
public class ZoomImageView extends ImageView {

    private static final float DOUBLE_TAP_ZOOM = 3f;
    private static final float MAX_ZOOM = 6f;

    private final Matrix matrix = new Matrix();
    private final float[] vals = new float[9];
    private final RectF rect = new RectF();
    private float baseScale = 1f;
    private float lastX, lastY;
    private final ScaleGestureDetector scaleDetector;
    private final GestureDetector tapDetector;

    public ZoomImageView(Context context) {
        super(context);
        setScaleType(ScaleType.MATRIX);

        scaleDetector = new ScaleGestureDetector(context,
                new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                    @Override
                    public boolean onScale(ScaleGestureDetector d) {
                        float cur = currentScale();
                        float factor = d.getScaleFactor();
                        float target = cur * factor;
                        float min = baseScale;
                        float max = baseScale * MAX_ZOOM;
                        if (target < min) factor = min / cur;
                        if (target > max) factor = max / cur;
                        matrix.postScale(factor, factor, d.getFocusX(), d.getFocusY());
                        fixTranslation();
                        setImageMatrix(matrix);
                        return true;
                    }
                });

        tapDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onDown(MotionEvent e) {
                return true;
            }

            @Override
            public boolean onDoubleTap(MotionEvent e) {
                if (getDrawable() == null) return true;
                if (isZoomed()) {
                    fit();
                } else {
                    float factor = (baseScale * DOUBLE_TAP_ZOOM) / currentScale();
                    matrix.postScale(factor, factor, e.getX(), e.getY());
                    fixTranslation();
                    setImageMatrix(matrix);
                }
                return true;
            }
        });
        tapDetector.setIsLongpressEnabled(false);
    }

    @Override
    public void setImageDrawable(Drawable d) {
        super.setImageDrawable(d);
        fit();
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        fit();
    }

    private boolean isZoomed() {
        return currentScale() > baseScale * 1.05f;
    }

    private float currentScale() {
        matrix.getValues(vals);
        return vals[Matrix.MSCALE_X];
    }

    private void fit() {
        Drawable d = getDrawable();
        int vw = getWidth();
        int vh = getHeight();
        matrix.reset();
        if (d == null || vw == 0 || vh == 0) {
            setImageMatrix(matrix);
            return;
        }
        float dw = d.getIntrinsicWidth();
        float dh = d.getIntrinsicHeight();
        if (dw <= 0 || dh <= 0) {
            setImageMatrix(matrix);
            return;
        }
        baseScale = Math.min(vw / dw, vh / dh);
        matrix.postScale(baseScale, baseScale);
        matrix.postTranslate((vw - dw * baseScale) / 2f, (vh - dh * baseScale) / 2f);
        setImageMatrix(matrix);
    }

    private RectF displayRect() {
        Drawable d = getDrawable();
        rect.set(0, 0, d.getIntrinsicWidth(), d.getIntrinsicHeight());
        matrix.mapRect(rect);
        return rect;
    }

    private void fixTranslation() {
        if (getDrawable() == null) return;
        RectF r = displayRect();
        float vw = getWidth();
        float vh = getHeight();
        float dx = 0, dy = 0;
        if (r.width() <= vw) {
            dx = (vw - r.width()) / 2f - r.left;
        } else if (r.left > 0) {
            dx = -r.left;
        } else if (r.right < vw) {
            dx = vw - r.right;
        }
        if (r.height() <= vh) {
            dy = (vh - r.height()) / 2f - r.top;
        } else if (r.top > 0) {
            dy = -r.top;
        } else if (r.bottom < vh) {
            dy = vh - r.bottom;
        }
        matrix.postTranslate(dx, dy);
    }

    private void disallowParent(boolean disallow) {
        ViewParent p = getParent();
        if (p != null) p.requestDisallowInterceptTouchEvent(disallow);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (getDrawable() == null) return super.onTouchEvent(e);

        scaleDetector.onTouchEvent(e);
        tapDetector.onTouchEvent(e);

        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                lastX = e.getX();
                lastY = e.getY();
                disallowParent(isZoomed());
                break;

            case MotionEvent.ACTION_POINTER_DOWN:
                disallowParent(true);
                break;

            case MotionEvent.ACTION_MOVE:
                if (!scaleDetector.isInProgress() && e.getPointerCount() == 1 && isZoomed()) {
                    float dx = e.getX() - lastX;
                    float dy = e.getY() - lastY;
                    RectF r = displayRect();
                    boolean canPanX = r.width() > getWidth() + 1;
                    boolean atLeft = r.left >= -1;
                    boolean atRight = r.right <= getWidth() + 1;
                    if (!canPanX || (dx > 0 && atLeft) || (dx < 0 && atRight)) {
                        disallowParent(false);
                        if (canPanX) dx = 0;
                    } else {
                        disallowParent(true);
                    }
                    matrix.postTranslate(dx, dy);
                    fixTranslation();
                    setImageMatrix(matrix);
                }
                lastX = e.getX();
                lastY = e.getY();
                break;

            case MotionEvent.ACTION_POINTER_UP: {
                // Avoid a jump when one finger lifts during a pinch.
                int idx = e.getActionIndex() == 0 ? 1 : 0;
                lastX = e.getX(idx);
                lastY = e.getY(idx);
                break;
            }

            default:
                break;
        }
        return true;
    }
}
