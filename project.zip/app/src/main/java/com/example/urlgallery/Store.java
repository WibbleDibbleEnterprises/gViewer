package com.example.urlgallery;

import java.nio.ByteBuffer;
import java.util.ArrayList;

/** Holds extracted zip images in memory only (nothing is ever written to storage). */
final class Store {
    static final long MAX_BYTES = 1024L * 1024 * 1024; // 1 GB ceiling

    private static final ArrayList<ByteBuffer> DATA = new ArrayList<>();
    private static long total = 0;

    private Store() {
    }

    /** Returns the new index, or -1 if the size ceiling would be exceeded. */
    static synchronized int add(byte[] bytes) {
        if (total + bytes.length > MAX_BYTES) return -1;
        ByteBuffer b = ByteBuffer.allocateDirect(bytes.length);
        b.put(bytes);
        b.flip();
        DATA.add(b);
        total += bytes.length;
        return DATA.size() - 1;
    }

    static synchronized byte[] bytes(int index) {
        if (index < 0 || index >= DATA.size()) return null;
        ByteBuffer dup = DATA.get(index).duplicate();
        byte[] out = new byte[dup.remaining()];
        dup.get(out);
        return out;
    }

    static synchronized long totalBytes() {
        return total;
    }

    /** Overwrite everything with zeros, then drop it. */
    static synchronized void wipe() {
        byte[] zeros = new byte[64 * 1024];
        for (ByteBuffer b : DATA) {
            ByteBuffer d = b.duplicate();
            d.clear();
            while (d.hasRemaining()) {
                int n = Math.min(d.remaining(), zeros.length);
                d.put(zeros, 0, n);
            }
        }
        DATA.clear();
        total = 0;
    }
}
