package com.example.urlgallery;

import android.content.Context;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.UUID;

import javax.crypto.Cipher;
import javax.crypto.CipherOutputStream;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * Temporary storage for extracted images.
 * Every file is AES-encrypted with a random key that exists only in memory,
 * so if a file ever survives (crash, reboot), it is unreadable without that key.
 * Files live in the app's private no-backup folder.
 */
final class Store {
    private static final long MIN_FREE = 100L * 1024 * 1024;
    private static final SecureRandom RNG = new SecureRandom();

    private static final ArrayList<File> FILES = new ArrayList<>();
    private static File dir;
    private static byte[] keyBytes;
    private static SecretKeySpec key;
    private static long total = 0;

    private Store() {
    }

    static synchronized void init(Context ctx) {
        if (dir == null) {
            dir = new File(ctx.getApplicationContext().getNoBackupFilesDir(), "t");
            //noinspection ResultOfMethodCallIgnored
            dir.mkdirs();
        }
    }

    private static void ensureKey() {
        if (key == null) {
            keyBytes = new byte[32];
            RNG.nextBytes(keyBytes);
            key = new SecretKeySpec(keyBytes, "AES");
        }
    }

    /** Encrypts and saves the bytes. Returns the new index. */
    static synchronized int add(byte[] data) throws IOException {
        if (dir == null) throw new IOException("storage not ready");
        if (dir.getUsableSpace() < data.length + MIN_FREE) throw new IOException("phone storage is nearly full");
        ensureKey();
        File f = new File(dir, UUID.randomUUID().toString().replace("-", ""));
        byte[] iv = new byte[16];
        RNG.nextBytes(iv);
        FileOutputStream fos = null;
        try {
            Cipher c = Cipher.getInstance("AES/CTR/NoPadding");
            c.init(Cipher.ENCRYPT_MODE, key, new IvParameterSpec(iv));
            fos = new FileOutputStream(f);
            fos.write(iv);
            CipherOutputStream cos = new CipherOutputStream(fos, c);
            int off = 0;
            while (off < data.length) {
                int n = Math.min(64 * 1024, data.length - off);
                cos.write(data, off, n);
                off += n;
            }
            cos.close();
            fos = null;
        } catch (GeneralSecurityException e) {
            //noinspection ResultOfMethodCallIgnored
            f.delete();
            throw new IOException("encryption failed");
        } catch (IOException e) {
            if (fos != null) {
                try {
                    fos.close();
                } catch (IOException ignore) {
                }
            }
            //noinspection ResultOfMethodCallIgnored
            f.delete();
            throw e;
        }
        FILES.add(f);
        total += data.length;
        return FILES.size() - 1;
    }

    /** Decrypts and returns the bytes, or null if unavailable. */
    static byte[] bytes(int index) {
        File f;
        SecretKeySpec k;
        synchronized (Store.class) {
            if (index < 0 || index >= FILES.size()) return null;
            f = FILES.get(index);
            k = key;
        }
        if (k == null) return null;
        try {
            byte[] all = new byte[(int) f.length()];
            DataInputStream in = new DataInputStream(new FileInputStream(f));
            try {
                in.readFully(all);
            } finally {
                in.close();
            }
            Cipher c = Cipher.getInstance("AES/CTR/NoPadding");
            c.init(Cipher.DECRYPT_MODE, k, new IvParameterSpec(all, 0, 16));
            return c.doFinal(all, 16, all.length - 16);
        } catch (Throwable t) {
            return null;
        }
    }

    static synchronized long totalBytes() {
        return total;
    }

    /** Throw away the key and delete every file in the folder, including any leftovers. */
    static synchronized void wipe() {
        FILES.clear();
        total = 0;
        if (keyBytes != null) {
            Arrays.fill(keyBytes, (byte) 0);
        }
        keyBytes = null;
        key = null;
        if (dir != null) {
            File[] list = dir.listFiles();
            if (list != null) {
                for (File f : list) {
                    //noinspection ResultOfMethodCallIgnored
                    f.delete();
                }
            }
        }
    }
}
