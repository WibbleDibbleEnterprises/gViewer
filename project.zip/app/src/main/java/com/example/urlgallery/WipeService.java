package com.example.urlgallery;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

/** Gets told when the app is swiped away from recents, and wipes everything. */
public class WipeService extends Service {

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_NOT_STICKY;
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        Store.init(getApplicationContext());
        Store.wipe();
        ImageLoader.clear();
        stopSelf();
        super.onTaskRemoved(rootIntent);
    }
}
