package com.example.urlgallery;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.view.View;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Loads images straight into memory (nothing is saved to storage). */
public class ImageLoader {

    public interface Callback {
        void done(Bitmap bmp);
    }

    private static final String UA =
            "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 "
                    + "(KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36";

    private static final ExecutorService POOL = Executors.newFixedThreadPool(4);
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final LruCache<String, Bitmap> CACHE =
            new LruCache<String, Bitmap>((int) (Runtime.getRuntime().maxMemory() / 8)) {
                @Override
                protected int sizeOf(String key, Bitmap value) {
                    return value.getByteCount();
                }
            };

    /** Drop everything held in memory. */
    public static void clear() {
        CACHE.evictAll();
    }

    public static void load(final View target, final String url, final int maxPx, final Callback cb) {
        final String key = url + "@" + maxPx;
        target.setTag(key);
        Bitmap hit = CACHE.get(key);
        if (hit != null) {
            cb.done(hit);
            return;
        }
        POOL.execute(new Runnable() {
            @Override
            public void run() {
                // Skip work if this view has been recycled for another image.
                if (!key.equals(target.getTag())) return;
                final Bitmap bmp = fetch(url, maxPx);
                if (bmp != null) CACHE.put(key, bmp);
                MAIN.post(new Runnable() {
                    @Override
                    public void run() {
                        if (key.equals(target.getTag())) cb.done(bmp);
                    }
                });
            }
        });
    }

    /** Opens a connection that returned HTTP 200, following redirects. Null on failure. */
    static HttpURLConnection open(String url) {
        HttpURLConnection c = null;
        try {
            URL u = new URL(url);
            for (int hop = 0; hop < 6; hop++) {
                c = (HttpURLConnection) u.openConnection();
                c.setConnectTimeout(15000);
                c.setReadTimeout(30000);
                c.setInstanceFollowRedirects(false);
                c.setRequestProperty("User-Agent", UA);
                c.setRequestProperty("Referer", u.getProtocol() + "://" + u.getHost() + "/");
                c.setRequestProperty("Accept", "*/*");
                int code = c.getResponseCode();
                if (code >= 300 && code < 400) {
                    String loc = c.getHeaderField("Location");
                    c.disconnect();
                    c = null;
                    if (loc == null) return null;
                    u = new URL(u, loc);
                    continue;
                }
                if (code != 200) {
                    c.disconnect();
                    return null;
                }
                return c;
            }
        } catch (Throwable t) {
            if (c != null) c.disconnect();
        }
        return null;
    }

    private static Bitmap fetch(String url, int maxPx) {
        HttpURLConnection c = null;
        try {
            byte[] data;
            if (url.startsWith("mem:")) {
                data = Store.bytes(Integer.parseInt(url.substring(4)));
                if (data == null) return null;
            } else {
                c = open(url);
                if (c == null) return null;
                InputStream in = c.getInputStream();
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[16384];
                int n;
                int total = 0;
                while ((n = in.read(buf)) > 0) {
                    out.write(buf, 0, n);
                    total += n;
                    if (total > 60 * 1024 * 1024) return null;
                }
                data = out.toByteArray();
            }

            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(data, 0, data.length, o);
            if (o.outWidth <= 0 || o.outHeight <= 0) return null;
            int sample = 1;
            while (Math.max(o.outWidth, o.outHeight) / (sample * 2) >= maxPx) sample *= 2;
            BitmapFactory.Options d = new BitmapFactory.Options();
            d.inSampleSize = sample;
            return BitmapFactory.decodeByteArray(data, 0, data.length, d);
        } catch (Throwable t) {
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }
}
