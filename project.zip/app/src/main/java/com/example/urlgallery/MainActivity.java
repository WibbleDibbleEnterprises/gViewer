package com.example.urlgallery;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.concurrent.atomic.AtomicBoolean;

public class MainActivity extends Activity {

    private final ArrayList<String> urls = new ArrayList<>();
    private EditText input;
    private LinearLayout panel;
    private TextView status;
    private Button toggle;
    private RecyclerView grid;
    private GridAdapter adapter;
    private Button showBtn;
    private boolean loading = false;
    private final AtomicBoolean cancel = new AtomicBoolean(false);
    private final Handler ui = new Handler(Looper.getMainLooper());
    private int cellSize;
    private float density;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Store.init(this);
        Store.wipe();
        try {
            startService(new Intent(this, WipeService.class));
        } catch (Throwable ignore) {
        }
        density = getResources().getDisplayMetrics().density;
        int screenW = getResources().getDisplayMetrics().widthPixels;
        int margin = (int) (1 * density);
        cellSize = screenW / 3 - 2 * margin;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF111111);
        int pad = dp(8);
        root.setPadding(pad, pad, pad, 0);

        // Header: status + edit toggle
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        status = new TextView(this);
        status.setTextColor(0xFFAAAAAA);
        status.setTextSize(14);
        header.addView(status, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        toggle = new Button(this);
        toggle.setText("Edit list");
        header.addView(toggle, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(header);

        // Input panel
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        input = new EditText(this);
        input.setHint("Paste image URLs here, one per line");
        input.setHintTextColor(0xFF777777);
        input.setTextColor(0xFFFFFFFF);
        input.setTextSize(13);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        input.setImeOptions(EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING);
        input.setSaveEnabled(false);
        input.setMinLines(6);
        input.setMaxLines(10);
        input.setGravity(Gravity.TOP | Gravity.START);
        input.setBackgroundColor(0xFF1C1C1C);
        input.setPadding(dp(8), dp(8), dp(8), dp(8));
        panel.addView(input, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        final Button show = new Button(this);
        showBtn = show;
        show.setText("Show gallery");
        Button paste = new Button(this);
        paste.setText("Paste");
        Button clear = new Button(this);
        clear.setText("Clear");
        buttons.addView(show);
        buttons.addView(paste);
        buttons.addView(clear);
        panel.addView(buttons);
        root.addView(panel);

        // Grid
        grid = new RecyclerView(this);
        grid.setLayoutManager(new GridLayoutManager(this, 3));
        adapter = new GridAdapter();
        grid.setAdapter(adapter);
        root.addView(grid, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);

        show.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                build(true);
            }
        });
        paste.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clip = cm.getPrimaryClip();
                if (clip != null && clip.getItemCount() > 0) {
                    CharSequence t = clip.getItemAt(0).coerceToText(MainActivity.this);
                    if (t != null && t.length() > 0) {
                        if (input.getText().length() > 0) input.append("\n");
                        input.append(t);
                    }
                }
            }
        });
        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                input.setText("");
                build(false);
            }
        });
        toggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setPanelVisible(panel.getVisibility() != View.VISIBLE);
            }
        });

        build(false);
        setPanelVisible(urls.isEmpty());
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        cancel.set(true);
        ImageLoader.clear();
        Store.wipe();
        urls.clear();
    }

    private int dp(int v) {
        return (int) (v * density);
    }

    private void setPanelVisible(boolean visible) {
        panel.setVisibility(visible ? View.VISIBLE : View.GONE);
        toggle.setText(visible ? "Hide" : "Edit list");
    }

    private static boolean isZipUrl(String u) {
        String x = u;
        int q = x.indexOf('?');
        if (q >= 0) x = x.substring(0, q);
        int h = x.indexOf('#');
        if (h >= 0) x = x.substring(0, h);
        x = x.toLowerCase(java.util.Locale.ROOT);
        String[] exts = {".zip", ".rar", ".7z", ".tar", ".tgz", ".tar.gz", ".tbz2", ".tar.bz2",
                ".txz", ".tar.xz", ".cbz", ".cbr", ".cb7"};
        for (String e : exts) {
            if (x.endsWith(e)) return true;
        }
        return false;
    }

    private void build(final boolean hidePanel) {
        if (loading) return;
        String text = input.getText().toString();

        // Each entry: {url, "zip" or "img"}. A "zip:" prefix forces zip handling.
        final ArrayList<String[]> tokens = new ArrayList<>();
        LinkedHashSet<String> seen = new LinkedHashSet<>();
        boolean anyZip = false;
        Matcher m = Pattern.compile("((?:zip|archive|rar|7z):)?(https?://[^\\s\"'<>]+)", Pattern.CASE_INSENSITIVE).matcher(text);
        while (m.find()) {
            String u = m.group(2);
            if (!seen.add(u)) continue;
            boolean zip = m.group(1) != null || isZipUrl(u);
            if (zip) anyZip = true;
            tokens.add(new String[]{u, zip ? "zip" : "img"});
        }

        // Start fresh: drop anything from an earlier run.
        ImageLoader.clear();
        Store.wipe();

        if (!anyZip) {
            urls.clear();
            for (String[] t : tokens) urls.add(t[0]);
            adapter.notifyDataSetChanged();
            status.setText(urls.isEmpty() ? "No images yet" : urls.size() + " images");
            if (hidePanel && !urls.isEmpty()) setPanelVisible(false);
            return;
        }

        loading = true;
        showBtn.setEnabled(false);
        urls.clear();
        adapter.notifyDataSetChanged();
        status.setText("Downloading archive…");

        new Thread(new Runnable() {
            @Override
            public void run() {
                final ArrayList<String> result = new ArrayList<>();
                final StringBuilder warn = new StringBuilder();
                ZipLoader.Progress prog = new ZipLoader.Progress() {
                    @Override
                    public void update(final String t) {
                        ui.post(new Runnable() {
                            @Override
                            public void run() {
                                if (!cancel.get()) status.setText(t);
                            }
                        });
                    }
                };
                for (String[] t : tokens) {
                    if (cancel.get()) break;
                    if (t[1].equals("img")) {
                        result.add(t[0]);
                        continue;
                    }
                    try {
                        ZipLoader.Result r = ZipLoader.load(t[0], prog, cancel);
                        result.addAll(r.ids);
                        if (r.warning != null) warn.append(r.warning).append(' ');
                        if (r.ids.isEmpty() && r.warning == null) warn.append("No images found in the archive. ");
                    } catch (Throwable ex) {
                        String msg = ex.getMessage() == null ? ex.toString() : ex.getMessage();
                        warn.append("Archive failed: ").append(msg).append(". ");
                    }
                }
                ui.post(new Runnable() {
                    @Override
                    public void run() {
                        loading = false;
                        showBtn.setEnabled(true);
                        if (cancel.get()) return;
                        urls.clear();
                        urls.addAll(result);
                        adapter.notifyDataSetChanged();
                        String base = urls.isEmpty() ? "No images yet" : urls.size() + " images";
                        status.setText(warn.length() > 0 ? base + " — " + warn.toString().trim() : base);
                        if (hidePanel && !urls.isEmpty() && warn.length() == 0) setPanelVisible(false);
                    }
                });
            }
        }).start();
    }

    private class GridAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            ImageView iv = new ImageView(MainActivity.this);
            RecyclerView.LayoutParams lp = new RecyclerView.LayoutParams(cellSize, cellSize);
            int mg = (int) (1 * density);
            lp.setMargins(mg, mg, mg, mg);
            iv.setLayoutParams(lp);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setBackgroundColor(0xFF222222);
            return new RecyclerView.ViewHolder(iv) {
            };
        }

        @Override
        public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
            final ImageView iv = (ImageView) holder.itemView;
            final int pos = position;
            iv.setImageDrawable(null);
            iv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(MainActivity.this, ViewerActivity.class);
                    i.putStringArrayListExtra("urls", urls);
                    i.putExtra("pos", pos);
                    startActivity(i);
                }
            });
            ImageLoader.load(iv, urls.get(position), 400, new ImageLoader.Callback() {
                @Override
                public void done(android.graphics.Bitmap bmp) {
                    if (bmp != null) iv.setImageBitmap(bmp);
                }
            });
        }

        @Override
        public int getItemCount() {
            return urls.size();
        }
    }
}
