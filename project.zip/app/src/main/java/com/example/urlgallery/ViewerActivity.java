package com.example.urlgallery;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import java.util.ArrayList;

public class ViewerActivity extends Activity {

    private ArrayList<String> urls;
    private ViewPager2 pager;
    private RecyclerView strip;
    private StripAdapter stripAdapter;
    private TextView counter;
    private float density;
    private int thumbPx;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        density = getResources().getDisplayMetrics().density;
        thumbPx = (int) (64 * density);

        urls = getIntent().getStringArrayListExtra("urls");
        if (urls == null) urls = new ArrayList<>();
        int start = getIntent().getIntExtra("pos", 0);
        if (start < 0 || start >= urls.size()) start = 0;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF000000);

        FrameLayout top = new FrameLayout(this);
        pager = new ViewPager2(this);
        pager.setAdapter(new PagerAdapter());
        pager.setOffscreenPageLimit(1);
        top.addView(pager, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        counter = new TextView(this);
        counter.setTextColor(0xFFFFFFFF);
        counter.setTextSize(16);
        counter.setPadding(dp(14), dp(6), dp(14), dp(6));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0x99000000);
        bg.setCornerRadius(dp(16));
        counter.setBackground(bg);
        FrameLayout.LayoutParams clp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        clp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        clp.topMargin = dp(12);
        top.addView(counter, clp);

        root.addView(top, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        strip = new RecyclerView(this);
        strip.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        stripAdapter = new StripAdapter();
        strip.setAdapter(stripAdapter);
        strip.setBackgroundColor(0xBB000000);
        strip.setPadding(0, dp(4), 0, dp(4));
        FrameLayout.LayoutParams slp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, thumbPx + dp(8));
        slp.gravity = Gravity.BOTTOM;
        top.addView(strip, slp);

        // Hidden until the screen is tapped once.
        counter.setVisibility(View.GONE);
        strip.setVisibility(View.GONE);

        setContentView(root);

        pager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                updateSelection(position);
            }
        });
        pager.setCurrentItem(start, false);
        updateSelection(start);
    }

    private void toggleOverlays() {
        boolean show = counter.getVisibility() != View.VISIBLE;
        counter.setVisibility(show ? View.VISIBLE : View.GONE);
        strip.setVisibility(show ? View.VISIBLE : View.GONE);
        if (show) updateSelection(pager.getCurrentItem());
    }

    private int dp(int v) {
        return (int) (v * density);
    }

    private void updateSelection(int pos) {
        counter.setText((pos + 1) + " / " + urls.size());
        stripAdapter.select(pos);
        LinearLayoutManager lm = (LinearLayoutManager) strip.getLayoutManager();
        int offset = Math.max(0, strip.getWidth() / 2 - thumbPx / 2);
        if (strip.getWidth() == 0) {
            offset = Math.max(0, getResources().getDisplayMetrics().widthPixels / 2 - thumbPx / 2);
        }
        lm.scrollToPositionWithOffset(pos, offset);
    }

    // ---- Full-size pages (swipe) ----
    private static class PageHolder extends RecyclerView.ViewHolder {
        final ImageView iv;
        final TextView tv;

        PageHolder(FrameLayout fl, ImageView iv, TextView tv) {
            super(fl);
            this.iv = iv;
            this.tv = tv;
        }
    }

    private class PagerAdapter extends RecyclerView.Adapter<PageHolder> {
        @Override
        public PageHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            FrameLayout fl = new FrameLayout(ViewerActivity.this);
            fl.setLayoutParams(new RecyclerView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            ZoomImageView iv = new ZoomImageView(ViewerActivity.this);
            iv.setOnTapListener(new ZoomImageView.OnTapListener() {
                @Override
                public void onTap() {
                    toggleOverlays();
                }
            });
            fl.addView(iv, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            TextView tv = new TextView(ViewerActivity.this);
            tv.setTextColor(0xFFCCCCCC);
            tv.setGravity(Gravity.CENTER);
            tv.setPadding(dp(24), dp(24), dp(24), dp(24));
            fl.addView(tv, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            return new PageHolder(fl, iv, tv);
        }

        @Override
        public void onBindViewHolder(PageHolder h, int position) {
            final ImageView iv = h.iv;
            final TextView tv = h.tv;
            final String url = urls.get(position);
            iv.setImageDrawable(null);
            tv.setText("Loading…");
            tv.setVisibility(View.VISIBLE);
            ImageLoader.load(iv, url, 2000, new ImageLoader.Callback() {
                @Override
                public void done(Bitmap bmp) {
                    if (bmp != null) {
                        iv.setImageBitmap(bmp);
                        tv.setVisibility(View.GONE);
                    } else {
                        tv.setText("Couldn't load this image\n\n" + url);
                        tv.setVisibility(View.VISIBLE);
                    }
                }
            });
        }

        @Override
        public int getItemCount() {
            return urls.size();
        }
    }

    // ---- Bottom thumbnail carousel ----
    private class StripAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        private int selected = -1;

        void select(int pos) {
            int old = selected;
            selected = pos;
            if (old >= 0) notifyItemChanged(old);
            notifyItemChanged(pos);
        }

        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            ImageView iv = new ImageView(ViewerActivity.this);
            RecyclerView.LayoutParams lp = new RecyclerView.LayoutParams(thumbPx, thumbPx);
            lp.setMargins(dp(2), 0, dp(2), 0);
            iv.setLayoutParams(lp);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            return new RecyclerView.ViewHolder(iv) {
            };
        }

        @Override
        public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
            final ImageView iv = (ImageView) holder.itemView;
            final int pos = position;
            boolean sel = (position == selected);
            iv.setImageDrawable(null);
            iv.setBackgroundColor(sel ? 0xFFFFFFFF : 0xFF222222);
            int p = sel ? dp(3) : 0;
            iv.setPadding(p, p, p, p);
            iv.setAlpha(sel ? 1f : 0.55f);
            iv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    pager.setCurrentItem(pos, false);
                }
            });
            ImageLoader.load(iv, urls.get(position), 400, new ImageLoader.Callback() {
                @Override
                public void done(Bitmap bmp) {
                    if (bmp != null) iv.setImageBitmap(bmp);
                }
            });
        }

        @Override
        public int getItemCount() {
            return urls.size();
        }
    }
}
